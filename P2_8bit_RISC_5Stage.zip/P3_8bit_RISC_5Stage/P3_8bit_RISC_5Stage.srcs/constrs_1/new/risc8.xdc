## 100 MHz System Clock Constraint (10.0 ns period) for Artix-7 FPGA
create_clock -period 10.000 -name sys_clk -waveform {0.000 5.000} [get_ports clk]