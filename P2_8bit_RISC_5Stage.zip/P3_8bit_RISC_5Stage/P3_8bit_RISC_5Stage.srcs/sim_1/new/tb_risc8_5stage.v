`timescale 1ns/1ps

module tb_risc8_5stage;

    reg clk = 0;
    reg rst = 1;
    wire       halted;
    wire [7:0] pc;
    wire [3:0] flags;        // UPGRADE: {Z, C, N, V} from the core
    wire       instr_done;

    // Leave IMEM_FILE empty to use the built-in ROM program in imem.v
    risc8_5stage_core #(.IMEM_FILE("")) dut (
        .clk        (clk),
        .rst        (rst),
        .halted     (halted),
        .pc_out     (pc),
        .flags_out  (flags),
        .instr_done (instr_done)
    );

    // 100 MHz clock (10 ns period)
    initial forever #5 clk = ~clk;

    integer cycles     = 0;
    integer retired    = 0;
    integer stalls     = 0;
    integer ex_flushes = 0;  // Conditional branches resolved in EX (2-cycle flush)
    integer id_jmps    = 0;  // UPGRADE: Early JMP resolved in ID (1-cycle flush)
    integer fwds       = 0;
    integer errors     = 0;

    // Per-cycle pipeline monitor
    always @(posedge clk) if (!rst && !halted) begin
        cycles <= cycles + 1;
        if (instr_done)      retired    <= retired    + 1;
        if (dut.stall)       stalls     <= stalls     + 1;
        if (dut.take_branch) ex_flushes <= ex_flushes + 1;
        if (dut.id_take_jmp) id_jmps    <= id_jmps    + 1;
        if (dut.idex_valid && (dut.fwd_a_sel != 2'b00 || dut.fwd_b_sel != 2'b00))
            fwds <= fwds + 1;

        $display("t=%6t PC=%02h | ID:%s%04h | EX:v%b | MEM:v%b | WB:%s R%0d<=%02h | Z=%b C=%b N=%b V=%b %s%s%s%s",
                 $time, pc,
                 dut.ifid_valid ? " " : "-", dut.ifid_instr,
                 dut.idex_valid, dut.exmem_valid,
                 dut.memwb_reg_we ? "w" : "-", dut.memwb_rd, dut.memwb_data,
                 flags[3], flags[2], flags[1], flags[0],
                 dut.stall       ? " STALL"             : "",
                 dut.take_branch ? " BRANCH->flush 2"  : "",
                 dut.id_take_jmp ? " EARLY_JMP->flush 1": "",
                 (dut.idex_valid && (dut.fwd_a_sel != 2'b00 || dut.fwd_b_sel != 2'b00)) ? " fwd" : "");
    end

    task check_reg(input [2:0] r, input [7:0] exp);
        if (dut.u_rf.r[r] !== exp) begin
            $display("FAIL  R%0d = %02h, expected %02h", r, dut.u_rf.r[r], exp);
            errors = errors + 1;
        end else
            $display("PASS  R%0d = %02h", r, exp);
    endtask

    initial begin
        $dumpfile("risc8_5stage.vcd");
        $dumpvars(0, tb_risc8_5stage);

        #22 rst = 0;
        wait (halted);
        @(posedge clk); @(posedge clk);

        $display("\n================ Student: Pham Xuan Nhat Minh - ID: HE200288 ================");
        $display("------------- Register / Memory / Upgraded Flags Check -------------");
        check_reg(1, 8'h00);  check_reg(2, 8'h0F);
        check_reg(3, 8'h01);  check_reg(4, 8'h20);
        check_reg(5, 8'h00);  check_reg(6, 8'h66);
        check_reg(7, 8'h00);

        if (dut.u_dmem.mem[8'h20] !== 8'h0F) begin
            $display("FAIL  MEM[20] = %02h, expected 0F", dut.u_dmem.mem[8'h20]);
            errors = errors + 1;
        end else
            $display("PASS  MEM[20] = 0F");

        // Final instruction before JMP is ADDI R5, 1 (0xFF + 0x01 = 0x00)
        // Expected flags: Z=1, C=1, N=0, V=0 -> 4'b1100
        if (flags !== 4'b1100) begin
            $display("FAIL  flags Z=%b C=%b N=%b V=%b, expected 1100",
                     flags[3], flags[2], flags[1], flags[0]);
            errors = errors + 1;
        end else
            $display("PASS  flags Z=1 C=1 N=0 V=0");

        if (id_jmps !== 1) begin
            $display("FAIL  Early JMP count = %0d, expected 1", id_jmps);
            errors = errors + 1;
        end else
            $display("PASS  Early JMP (1-cycle penalty) verified");

        $display("\ncycles=%0d  instructions=%0d  CPI=%0.2f  load-use stalls=%0d  EX branches=%0d  Early ID JMPs=%0d  forwards=%0d",
                 cycles, retired, cycles * 1.0 / retired, stalls, ex_flushes, id_jmps, fwds);

        if (errors == 0) $display("*** ALL TESTS PASSED (10 of 10 checks OK) ***");
        else             $display("*** %0d TEST(S) FAILED ***", errors);
        $finish;
    end

    initial begin #20000 $display("TIMEOUT"); $finish; end

endmodule