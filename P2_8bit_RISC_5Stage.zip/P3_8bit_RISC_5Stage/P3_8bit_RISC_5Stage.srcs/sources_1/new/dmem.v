`timescale 1ns/1ps

(* KEEP_HIERARCHY = "yes" *)
module dmem (
    input  wire       clk,
    input  wire       we,
    input  wire [7:0] addr,
    input  wire [7:0] wdata,
    output wire [7:0] rdata
);

    (* ram_style = "distributed" *) reg [7:0] mem [0:255];
    integer i;

    initial for (i = 0; i < 256; i = i + 1) mem[i] = 8'h00;

    always @(posedge clk)
        if (we) mem[addr] <= wdata;

    assign rdata = mem[addr];

endmodule