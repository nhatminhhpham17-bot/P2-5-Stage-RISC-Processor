`timescale 1ns/1ps

(* KEEP_HIERARCHY = "yes" *)
module hazard_unit (
    // Instruction in ID (Stage 2)
    input  wire       id_valid,
    input  wire [2:0] id_ra_addr,
    input  wire [2:0] id_rb_addr,
    input  wire       id_uses_a,
    input  wire       id_uses_b,

    // Instruction in EX (Stage 3)
    input  wire       ex_valid,
    input  wire       ex_mem_to_reg,
    input  wire [2:0] ex_rd,
    input  wire [2:0] ex_ra_addr,
    input  wire [2:0] ex_rb_addr,
    input  wire       ex_uses_a,
    input  wire       ex_uses_b,

    // Instruction in MEM (Stage 4)
    input  wire       mem_reg_we,
    input  wire       mem_mem_to_reg,
    input  wire [2:0] mem_rd,

    // Instruction in WB (Stage 5)
    input  wire       wb_reg_we,
    input  wire [2:0] wb_rd,

    // Outputs
    output reg  [1:0] fwd_a_sel,
    output reg  [1:0] fwd_b_sel,
    output wire       stall
);

    always @(*) begin
        if (ex_uses_a && mem_reg_we && !mem_mem_to_reg && (mem_rd == ex_ra_addr))
            fwd_a_sel = 2'b10; // From EX/MEM
        else if (ex_uses_a && wb_reg_we && (wb_rd == ex_ra_addr))
            fwd_a_sel = 2'b01; // From MEM/WB
        else
            fwd_a_sel = 2'b00; // From ID/EX
    end

    always @(*) begin
        if (ex_uses_b && mem_reg_we && !mem_mem_to_reg && (mem_rd == ex_rb_addr))
            fwd_b_sel = 2'b10;
        else if (ex_uses_b && wb_reg_we && (wb_rd == ex_rb_addr))
            fwd_b_sel = 2'b01;
        else
            fwd_b_sel = 2'b00;
    end

    assign stall = id_valid && ex_valid && ex_mem_to_reg &&
                   ((id_uses_a && (id_ra_addr == ex_rd)) ||
                    (id_uses_b && (id_rb_addr == ex_rd)));

endmodule