`timescale 1ns/1ps

(* KEEP_HIERARCHY = "yes" *)
module alu (
    input  wire [7:0] a,        // Operand A : from forwarding mux ex_opA
    input  wire [7:0] b,        // Operand B : register value OR 8-bit immediate
    input  wire [2:0] alu_op,   // Operation select : from control_unit.v
    output reg  [7:0] y,        // 8-bit result
    output reg        c,        // Carry-out (ADD), borrow (SUB), shifted-out bit (SHL/SHR)
    output wire       z,        // Zero flag : 1 when y == 0
    output wire       n,        // UPGRADE: Negative flag (MSB of result)
    output reg        v         // UPGRADE: Signed 2's complement Overflow flag
);

    localparam ALU_ADD   = 3'd0,
               ALU_SUB   = 3'd1,
               ALU_AND   = 3'd2,
               ALU_OR    = 3'd3,
               ALU_XOR   = 3'd4,
               ALU_SHL   = 3'd5,
               ALU_SHR   = 3'd6,
               ALU_PASSB = 3'd7;

    always @(*) begin
        c = 1'b0;
        v = 1'b0;

        case (alu_op)
            ALU_ADD  : begin
                {c, y} = {1'b0, a} + {1'b0, b};
                // Overflow occurs when adding two same-sign numbers yields opposite sign
                v = (~a[7] & ~b[7] & y[7]) | (a[7] & b[7] & ~y[7]);
            end

            ALU_SUB  : begin
                {c, y} = {1'b0, a} - {1'b0, b};
                // Overflow occurs when subtracting opposite-sign numbers yields wrong sign
                v = (~a[7] & b[7] & y[7]) | (a[7] & ~b[7] & ~y[7]);
            end

            ALU_AND  : y = a & b;
            ALU_OR   : y = a | b;
            ALU_XOR  : y = a ^ b;
            ALU_SHL  : {c, y} = {a, 1'b0};
            ALU_SHR  : {y, c} = {1'b0, a};
            ALU_PASSB: y = b;
            default  : y = 8'h00;
        endcase
    end

    assign z = (y == 8'h00);
    assign n = y[7];

endmodule