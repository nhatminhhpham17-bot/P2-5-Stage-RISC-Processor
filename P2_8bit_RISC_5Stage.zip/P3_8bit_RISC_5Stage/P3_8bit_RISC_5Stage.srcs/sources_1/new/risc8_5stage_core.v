`timescale 1ns/1ps

(* KEEP_HIERARCHY = "yes" *)
module risc8_5stage_core #(
    parameter IMEM_FILE = ""
) (
    input  wire       clk,
    input  wire       rst,
    output reg        halted,
    output wire [7:0] pc_out,
    output wire [3:0] flags_out,  // UPGRADE: {Z, C, N, V} status flags
    output wire       instr_done
);

    // =================================================================
    //  STAGE 1 : INSTRUCTION FETCH (IF)
    // =================================================================
    reg  [7:0]  pc;
    (* DONT_TOUCH = "TRUE" *) wire [15:0] if_instr;

    (* DONT_TOUCH = "TRUE" *) imem #(.INIT_FILE(IMEM_FILE)) u_imem (
        .addr  (pc),
        .instr (if_instr)
    );

    reg [15:0] ifid_instr;
    reg        ifid_valid;

    // =================================================================
    //  STAGE 2 : INSTRUCTION DECODE (ID)
    // =================================================================
    wire [3:0] id_opcode = ifid_instr[15:12];
    wire [2:0] id_rd     = ifid_instr[11:9];
    wire [2:0] id_rs1    = ifid_instr[8:6];
    wire [2:0] id_rs2    = ifid_instr[5:3];
    wire [7:0] id_imm8   = ifid_instr[7:0];

    wire [2:0] id_alu_op;
    wire id_alu_src_imm, id_ra_is_rd, id_rb_is_rd, id_uses_a, id_uses_b,
         id_reg_we, id_mem_to_reg, id_mem_we, id_flag_we,
         id_jump, id_br_z, id_br_nz, id_halt;

    (* DONT_TOUCH = "TRUE" *) control_unit u_ctrl (
        .opcode      (id_opcode),
        .alu_op      (id_alu_op),
        .alu_src_imm (id_alu_src_imm),
        .ra_is_rd    (id_ra_is_rd),
        .rb_is_rd    (id_rb_is_rd),
        .uses_a      (id_uses_a),
        .uses_b      (id_uses_b),
        .reg_we      (id_reg_we),
        .mem_to_reg  (id_mem_to_reg),
        .mem_we      (id_mem_we),
        .flag_we     (id_flag_we),
        .jump        (id_jump),
        .br_z        (id_br_z),
        .br_nz       (id_br_nz),
        .halt        (id_halt)
    );

    wire [2:0] id_ra_addr = id_ra_is_rd ? id_rd : id_rs1;
    wire [2:0] id_rb_addr = id_rb_is_rd ? id_rd : id_rs2;
    wire [7:0] id_ra_data, id_rb_data;

    // MEM/WB register signals
    reg        memwb_valid;
    reg        memwb_reg_we;
    reg  [2:0] memwb_rd;
    reg  [7:0] memwb_data;
    reg        memwb_halt;
    wire [7:0] wb_data = memwb_data;

    (* DONT_TOUCH = "TRUE" *) regfile u_rf (
        .clk     (clk),
        .rst     (rst),
        .ra_addr (id_ra_addr), .ra_data (id_ra_data),
        .rb_addr (id_rb_addr), .rb_data (id_rb_data),
        .we      (memwb_reg_we),
        .wr_addr (memwb_rd),
        .wr_data (wb_data)
    );

    // ID/EX pipeline register
    reg        idex_valid;
    reg  [2:0] idex_alu_op;
    reg        idex_alu_src_imm, idex_uses_a, idex_uses_b;
    reg        idex_reg_we, idex_mem_to_reg, idex_mem_we, idex_flag_we;
    reg        idex_jump, idex_br_z, idex_br_nz, idex_halt;
    reg  [2:0] idex_rd, idex_ra_addr, idex_rb_addr;
    reg  [7:0] idex_ra_data, idex_rb_data, idex_imm;

    // EX/MEM pipeline register
    reg        exmem_valid;
    reg        exmem_reg_we, exmem_mem_to_reg, exmem_mem_we, exmem_halt;
    reg  [2:0] exmem_rd;
    reg  [7:0] exmem_alu_y;
    reg  [7:0] exmem_addr;
    reg  [7:0] exmem_store_data;

    // =================================================================
    //  HAZARD UNIT
    // =================================================================
    wire [1:0] fwd_a_sel, fwd_b_sel;
    wire       stall;

    (* DONT_TOUCH = "TRUE" *) hazard_unit u_hazard (
        .id_valid       (ifid_valid),
        .id_ra_addr     (id_ra_addr),
        .id_rb_addr     (id_rb_addr),
        .id_uses_a      (id_uses_a),
        .id_uses_b      (id_uses_b),
        .ex_valid       (idex_valid),
        .ex_mem_to_reg  (idex_mem_to_reg),
        .ex_rd          (idex_rd),
        .ex_ra_addr     (idex_ra_addr),
        .ex_rb_addr     (idex_rb_addr),
        .ex_uses_a      (idex_uses_a),
        .ex_uses_b      (idex_uses_b),
        .mem_reg_we     (exmem_reg_we),
        .mem_mem_to_reg (exmem_mem_to_reg),
        .mem_rd         (exmem_rd),
        .wb_reg_we      (memwb_reg_we),
        .wb_rd          (memwb_rd),
        .fwd_a_sel      (fwd_a_sel),
        .fwd_b_sel      (fwd_b_sel),
        .stall          (stall)
    );

    // =================================================================
    //  STAGE 3 : EXECUTE (EX)
    // =================================================================
    wire [7:0] ex_opA = (fwd_a_sel == 2'b10) ? exmem_alu_y :
                        (fwd_a_sel == 2'b01) ? wb_data     : idex_ra_data;
    wire [7:0] ex_opB = (fwd_b_sel == 2'b10) ? exmem_alu_y :
                        (fwd_b_sel == 2'b01) ? wb_data     : idex_rb_data;

    wire [7:0] ex_alu_b = idex_alu_src_imm ? idex_imm : ex_opB;
    wire [7:0] ex_alu_y;
    wire       ex_alu_c, ex_alu_z, ex_alu_n, ex_alu_v;

    (* DONT_TOUCH = "TRUE" *) alu u_alu (
        .a      (ex_opA),
        .b      (ex_alu_b),
        .alu_op (idex_alu_op),
        .y      (ex_alu_y),
        .c      (ex_alu_c),
        .z      (ex_alu_z),
        .n      (ex_alu_n),
        .v      (ex_alu_v)
    );

    // UPGRADE: 4 Status flags (Z, C, N, V)
    reg flag_z, flag_c, flag_n, flag_v;

    // Conditional Branch resolution in EX (2-cycle penalty)
    wire take_branch = idex_valid &&
                       ((idex_br_z && flag_z) || (idex_br_nz && !flag_z));
    wire [7:0] branch_target = idex_imm;

    // HLT reached EX: stop fetching and squash younger instructions
    wire ex_halt = idex_valid && idex_halt;
    reg  draining;
    wire fetch_stop = draining || ex_halt;

    // UPGRADE: Early Unconditional Jump (JMP) resolved in ID (1-cycle penalty)
    // Only taken if no older conditional branch or HLT in EX overrides it.
    wire id_take_jmp = ifid_valid && id_jump && !take_branch && !fetch_stop;
    wire [7:0] jmp_target = id_imm8;

    // =================================================================
    //  STAGE 4 : MEMORY ACCESS (MEM)
    // =================================================================
    wire [7:0] mem_rdata;
    wire       mem_we = exmem_mem_we && !halted;

    (* DONT_TOUCH = "TRUE" *) dmem u_dmem (
        .clk   (clk),
        .we    (mem_we),
        .addr  (exmem_addr),
        .wdata (exmem_store_data),
        .rdata (mem_rdata)
    );

    wire [7:0] mem_result = exmem_mem_to_reg ? mem_rdata : exmem_alu_y;

    // =================================================================
    //  SEQUENTIAL LOGIC
    // =================================================================
    always @(posedge clk) begin
        if (rst) begin
            pc          <= 8'h00;
            ifid_instr  <= 16'h0000;  ifid_valid  <= 1'b0;
            idex_valid  <= 1'b0;
            idex_alu_op <= 3'd0; idex_alu_src_imm <= 1'b0;
            idex_uses_a <= 1'b0; idex_uses_b <= 1'b0;
            idex_reg_we <= 1'b0; idex_mem_to_reg <= 1'b0; idex_mem_we <= 1'b0;
            idex_flag_we <= 1'b0; idex_jump <= 1'b0; idex_br_z <= 1'b0;
            idex_br_nz <= 1'b0; idex_halt <= 1'b0;
            idex_rd <= 3'd0; idex_ra_addr <= 3'd0; idex_rb_addr <= 3'd0;
            idex_ra_data <= 8'h00; idex_rb_data <= 8'h00; idex_imm <= 8'h00;
            exmem_valid <= 1'b0; exmem_reg_we <= 1'b0; exmem_mem_to_reg <= 1'b0;
            exmem_mem_we <= 1'b0; exmem_halt <= 1'b0; exmem_rd <= 3'd0;
            exmem_alu_y <= 8'h00; exmem_addr <= 8'h00; exmem_store_data <= 8'h00;
            memwb_valid <= 1'b0; memwb_reg_we <= 1'b0; memwb_rd <= 3'd0;
            memwb_data  <= 8'h00; memwb_halt <= 1'b0;
            flag_z <= 1'b0; flag_c <= 1'b0; flag_n <= 1'b0; flag_v <= 1'b0;
            draining <= 1'b0; halted <= 1'b0;

        end else if (!halted) begin

            // ======== PC and IF/ID register (Stage 1 -> 2) ========
            // Priority: EX branch flush > EX halt > ID early JMP > load-use stall > normal
            if (take_branch) begin
                pc         <= branch_target;
                ifid_instr <= 16'h0000;
                ifid_valid <= 1'b0;
            end else if (fetch_stop) begin
                ifid_instr <= 16'h0000;
                ifid_valid <= 1'b0;
            end else if (id_take_jmp) begin
                pc         <= jmp_target;      // Early JMP redirects PC in ID
                ifid_instr <= 16'h0000;        // Flush only 1 wrong-path instruction in IF
                ifid_valid <= 1'b0;
            end else if (stall) begin
                // load-use stall: keep PC and IF/ID unchanged
            end else begin
                pc         <= pc + 8'd1;
                ifid_instr <= if_instr;
                ifid_valid <= 1'b1;
            end

            // ======== ID/EX register (Stage 2 -> 3) ========
            if (take_branch || fetch_stop || stall) begin
                idex_valid <= 1'b0;
            end else begin
                idex_valid       <= ifid_valid;
                idex_alu_op      <= id_alu_op;
                idex_alu_src_imm <= id_alu_src_imm;
                idex_uses_a      <= id_uses_a;
                idex_uses_b      <= id_uses_b;
                idex_reg_we      <= id_reg_we;
                idex_mem_to_reg  <= id_mem_to_reg;
                idex_mem_we      <= id_mem_we;
                idex_flag_we     <= id_flag_we;
                idex_jump        <= id_jump;
                idex_br_z        <= id_br_z;
                idex_br_nz       <= id_br_nz;
                idex_halt        <= id_halt;
                idex_rd          <= id_rd;
                idex_ra_addr     <= id_ra_addr;
                idex_rb_addr     <= id_rb_addr;
                idex_ra_data     <= id_ra_data;
                idex_rb_data     <= id_rb_data;
                idex_imm         <= id_imm8;
            end

            // ======== EX/MEM register (Stage 3 -> 4) ========
            exmem_valid      <= idex_valid;
            exmem_reg_we     <= idex_valid && idex_reg_we;
            exmem_mem_to_reg <= idex_valid && idex_mem_to_reg;
            exmem_mem_we     <= idex_valid && idex_mem_we;
            exmem_halt       <= ex_halt;
            exmem_rd         <= idex_rd;
            exmem_alu_y      <= ex_alu_y;
            exmem_addr       <= ex_opA;
            exmem_store_data <= ex_opB;

            // Update all 4 flags at the end of EX
            if (idex_valid && idex_flag_we) begin
                flag_z <= ex_alu_z;
                flag_c <= ex_alu_c;
                flag_n <= ex_alu_n;
                flag_v <= ex_alu_v;
            end

            if (ex_halt) draining <= 1'b1;

            // ======== MEM/WB register (Stage 4 -> 5) ========
            memwb_valid  <= exmem_valid;
            memwb_reg_we <= exmem_reg_we;
            memwb_rd     <= exmem_rd;
            memwb_data   <= mem_result;
            memwb_halt   <= exmem_halt;

            if (memwb_halt) halted <= 1'b1;

        end else begin
            memwb_reg_we <= 1'b0;
        end
    end

    assign pc_out     = pc;
    assign flags_out  = {flag_z, flag_c, flag_n, flag_v};
    assign instr_done = memwb_valid;

endmodule