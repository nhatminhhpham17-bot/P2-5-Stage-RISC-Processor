`timescale 1ns/1ps

(* KEEP_HIERARCHY = "yes" *)
module regfile (
    input  wire       clk,
    input  wire       rst,
    input  wire [2:0] ra_addr,
    output wire [7:0] ra_data,
    input  wire [2:0] rb_addr,
    output wire [7:0] rb_data,
    input  wire       we,
    input  wire [2:0] wr_addr,
    input  wire [7:0] wr_data
);

    (* DONT_TOUCH = "TRUE" *) reg [7:0] r [0:7];
    integer i;

    always @(posedge clk) begin
        if (rst)
            for (i = 0; i < 8; i = i + 1) r[i] <= 8'h00;
        else if (we)
            r[wr_addr] <= wr_data;
    end

    // Write-through bypass
    assign ra_data = (we && (wr_addr == ra_addr)) ? wr_data : r[ra_addr];
    assign rb_data = (we && (wr_addr == rb_addr)) ? wr_data : r[rb_addr];

endmodule